Thème blanc
Couleurs par défault utilisées : 
Polices par défaut utilisées : 

Instructions d'installation