<?php

/* Zone Bottom */

if(is_active_sidebar('trois')):


 dynamic_sidebar('trois'); 
 
 endif;?>